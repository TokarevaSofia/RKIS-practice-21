document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('content');

    let count = prompt("Введите количество новостей для отображения (от 1 до 12):", "3");

    try {
        if (count === null) {
            throw new Error("Отменено пользователем");
        }

        count = parseInt(count);

        if (isNaN(count)) {
            const error = new Error("Введено не число");
            error.name = "TypeError";
            error.description = "Пользователь ввел буквы или символы вместо цифр";
            error.userMessage = "Ошибка! Пожалуйста, введите ЧИСЛО от 1 до 12.";
            throw error;
        }

        if (count < 1 || count > 12) {
            const error = new Error("Число вне диапазона");
            error.name = "RangeError";
            error.description = "Число должно быть от 1 до 12";
            error.userMessage = "Ошибка! Количество новостей должно быть от 1 до 12.";
            throw error;
        }

        for (let i = 0; i < count; i++) {
            if (i >= newsArr.length) break;

            const item = newsArr[i];

            const div = document.createElement('div');
            div.className = 'news-item';

            const img = document.createElement('img');
            img.src = item.image;
            img.alt = "Новость";

            const span = document.createElement('span');
            span.textContent = item.date;

            const h3 = document.createElement('h3');
            h3.textContent = item.name;

            const p = document.createElement('p');
            p.textContent = item.text;

            div.append(img, span, h3, p);

            container.append(div);
        }

    } catch (error) {
        console.error(`[${error.name}] ${error.message}`);
        if (error.description) {
            console.log("Детали:", error.description);
        }

        container.innerHTML = `<div class="error-box">${error.userMessage || "Произошла неизвестная ошибка."}</div>`;
    }
});